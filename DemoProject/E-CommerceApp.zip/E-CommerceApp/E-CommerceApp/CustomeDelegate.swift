//
//  CustomeDelegate.swift
//  E-CommerceApp
//
//  Created by LaNet on 9/27/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit
@objc protocol AlertDelegate
{
    

}


class CustomeDelegate: UIViewController {
    
    var delegate:AlertDelegate?
    var netMsg = UILabel()
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var sharedInstance:CustomeDelegate {
        struct Singleton {
            static let instance = CustomeDelegate()
        }
        return Singleton.instance
    }

    
    func disappearMsg()
    {
        
        UIView.animateWithDuration(1.0, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
            self.netMsg.alpha = 0
            }, completion: {
                (finished: Bool) -> Void in
                 self.netMsg.removeFromSuperview()
            }
        )
      //  netMsg.removeFromSuperview()
    }
    
    func displayAlert(msg : String)
    {
        let sizeRect = UIScreen.mainScreen().bounds
        let height = ScreenSize.SCREEN_HEIGHT - 80
        let width = ScreenSize.SCREEN_WIDTH/2
        let originx = (ScreenSize.SCREEN_WIDTH - width) / 2
        
        netMsg.frame = CGRectMake(originx,height,width, 20)
        netMsg.font = netMsg.font.fontWithSize(10)
        netMsg.layer.cornerRadius = netMsg.frame.size.height / 2
        netMsg.clipsToBounds = true
        netMsg.text = msg //"Please Check Network"
        netMsg.textAlignment = NSTextAlignment.Center
        netMsg.layer.backgroundColor = UIColor.darkGrayColor().CGColor
        netMsg.textColor = UIColor.whiteColor()
        
//        UIView.animateWithDuration(1.0, delay: 0.0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
//            self.netMsg.alpha = 0
//            }, completion: {
//                (finished: Bool) -> Void in
//                 appDelegate().window?.addSubview(self.netMsg)
//            }
//        )
        
       appDelegate().window?.addSubview(netMsg)

       // self.view.addSubview(netMsg)
        NSTimer.scheduledTimerWithTimeInterval(3, target: self, selector: "disappearMsg", userInfo: nil, repeats: false)
        
    
    
    
    }
    

}
