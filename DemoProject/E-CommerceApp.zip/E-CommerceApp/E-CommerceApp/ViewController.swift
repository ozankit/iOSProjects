//
//  ViewController.swift
//  E-CommerceApp
//
//  Created by LaNet on 9/24/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var arrData = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        
        
        
        let url_string = NSString(format: "http://faceted-catalog-api.sophio.com/api/v1/56c49581-11b8-11e4-b695-002590948e4c/catalog-7/category/appearance-accessories/parts?returntype=json&year=&make=&model=&category=&subcategory=&parttype=&manufacturer=&engine=&submodel=&searchfor=&offset=0&pricerange=0")
        let url2 = url_string.stringByReplacingOccurrencesOfString(" ", withString: "%20")
        let url3 = url2.stringByReplacingOccurrencesOfString("\t", withString: "%20")
        let url4 = url3.stringByReplacingOccurrencesOfString("\n", withString: "%20")
        let url = NSURL(string: url4 as String)
        
        let request = NSMutableURLRequest(URL: url!)
        request.HTTPMethod = "POST"
        let data = NSData(contentsOfURL: url!)
        
        do
        {
            let jsonResult = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions()) as! NSMutableDictionary
           
           
            let a = jsonResult.valueForKey("results") as! NSMutableDictionary
            for var i = 0; i < a.valueForKey("parts")?.count; i += 1
            {
              var p_Data = ProductData()
               var data = a.valueForKey("parts")![i]! as! NSMutableDictionary
               p_Data.part_label = data.valueForKey("part_label") as! String
               p_Data.mfg_name = data.valueForKey("mfg_name") as! String
               p_Data.image_url = data.valueForKey("image_url") as! NSMutableArray
               p_Data.pricing = data.valueForKey("pricing")  as! NSMutableDictionary
               arrData.addObject(p_Data)
            }
             var cdd = arrData[0] as! ProductData
             print(cdd.mfg_name,"======\n",arrData[2])
           
        }
        catch
        {}

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

