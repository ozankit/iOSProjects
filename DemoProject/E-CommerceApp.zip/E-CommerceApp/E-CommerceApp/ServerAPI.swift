//
//  ServerAPI.swift
//  E-CommerceApp
//
//  Created by LaNet on 9/24/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit


import Foundation

let kRegisterFailedNotifiction = "RegisterFailedNotifiction"

class ServerAPI:NSObject {
    
    //MARK:- Shared Intanse Methods
    class var sharedInstance:ServerAPI {
        struct Singleton {
            static let instance = ServerAPI()
        }
        return Singleton.instance
    }
    
    func generateBoundaryString() -> String
    {
        return "Boundary-\(NSUUID().UUIDString)"
    }
    
    
    // MARK: - HTTP Handling
    func invokeHTTPRequestGET(url: NSURL,isEmbededToken:Bool, success: (result: AnyObject) -> (), failure: (error: NSString?) -> ()) {
        let request: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: .ReloadIgnoringLocalCacheData, timeoutInterval: 20.0)
        request.HTTPMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        
        callWS(request, success: success, failure: failure)
    }
    
    
    func invokeHTTPRequesPOST(url: NSURL, isEmbededToken:Bool, bodyContent: NSMutableDictionary, success: (result: AnyObject) -> (), failure: (error: NSString?) -> ()) {
        let request: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: .ReloadIgnoringLocalCacheData, timeoutInterval: 20.0)
        do {
            let jsonPost = try NSJSONSerialization.dataWithJSONObject(bodyContent, options: [])
            //            if (isEmbededToken == true)
            //            {
            //                let authValue = USER_DEFAULTS.objectForKey(kAuthenticationToken)as? String
            //                request.setValue(authValue, forHTTPHeaderField: "authId")
            //            }
            request.HTTPBody = jsonPost
            //                request.setValue("\(jsonPost.length)", forHTTPHeaderField: "Content-Length")
            request.HTTPMethod = "POST"
            
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("application/json", forHTTPHeaderField: "Accept")
        }catch
        {
            print("error in parse json data")
        }
        
        callWS(request, success: success, failure: failure);
    }
    
    func invokeHTTPRequesPUT(url: NSURL,isEmbededToken:Bool, bodyContent: NSDictionary, success: (result: AnyObject) -> (), failure: (error: NSString?) -> ()) {
        
        let request: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: .ReloadIgnoringLocalCacheData, timeoutInterval: 20.0)
        do {
            let jsonPost = try NSJSONSerialization.dataWithJSONObject(bodyContent, options: [])
            //            if (isEmbededToken == true)
            //            {
            //                let authValue = USER_DEFAULTS.objectForKey(kAuthenticationToken)as? String
            //                request.setValue(authValue, forHTTPHeaderField: "authId")
            //            }
            request.HTTPBody = jsonPost
            request.setValue("\(jsonPost.length)", forHTTPHeaderField: "Content-Length")
            request.HTTPMethod = "PUT"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
        }catch
        {
            print("error in parse json data")
        }
        
        callWS(request, success: success, failure: failure);
    }
    
    func invokeHTTPRequesDELETE(url: NSURL, isEmbededToken:Bool, bodyContent: NSDictionary, success: (result: AnyObject) -> (), failure: (error: NSString?) -> ()) {
        let request: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: .ReloadIgnoringLocalCacheData, timeoutInterval: 20.0)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        do {
            let jsonPost = try NSJSONSerialization.dataWithJSONObject(bodyContent, options: [])
            request.HTTPBody = jsonPost
            request.setValue("\(jsonPost.length)", forHTTPHeaderField: "Content-Length")
            request.HTTPMethod = "DELETE"
            
        }catch
        {
            print("error in parse json data")
        }
        
        callWS(request, success: success, failure: failure);
    }
    
    // upload Image
    func invokeImageUpload(url: NSURL, isEmbededToken:Bool,bodyContent: NSDictionary, bodyImage: UIImage, success: (result: AnyObject) -> (), failure: (error: NSString?) -> ())
    {
        let request: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: .ReloadIgnoringLocalCacheData, timeoutInterval: 20.0)
        
        let image_data = UIImageJPEGRepresentation(bodyImage, 0.1)
        let imgstr = image_data?.base64EncodedStringWithOptions(.Encoding64CharacterLineLength)
        
        let dict_param = NSMutableDictionary()
        
        dict_param["fileToUpload"] = imgstr
        dict_param["pwd"] = ""
        dict_param["ispwd"] = 0
        
        var finaldata = NSData()
        do {
            
            finaldata = try NSJSONSerialization.dataWithJSONObject(dict_param, options: .PrettyPrinted)
            
        } catch
        {
            print("json error: \(error)")
        }
        
        request.HTTPBody = finaldata
        
        let json = NSString(data: finaldata, encoding: NSUTF8StringEncoding)
        if let json = json {
            print(json)
        }
        
        if(image_data == nil)
        {
            doOnMainQueue({ () -> () in
                failure(error: "Please select another image")
                return
            })
            return
        }
        
        
        
        
        
        //        let fname = "fileToUpload"
        //        let mimetype = "image/png"
        
        //define the data post parameter
        
        //        body.appendData("--\(boundary)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        //        body.appendData("Content-Disposition:form-data; name=\"test\"\r\n\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        //        body.appendData("hi\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        //
        //        body.appendData("--\(boundary)\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        //        body.appendData("Content-Disposition:form-data; name=\"file\"; filename=\"\(fname)\"\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        //        body.appendData("Content-Type: \(mimetype)\r\n\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        //        body.appendData(image_data!)
        //        body.appendData("\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        //
        //        body.appendData("--\(boundary)--\r\n".dataUsingEncoding(NSUTF8StringEncoding)!)
        
        //body.appendData(jsonPost)
        //        request.HTTPBody = body
        
        
        
        
        callWS(request, success: success, failure: failure);
    }
    
    func callWS(request :NSMutableURLRequest ,success: (result: AnyObject) -> (), failure: (error: NSString?) -> ())
    {
        
        if(Reachability.isConnectedToNetwork())
        {
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request, completionHandler: {
                data, response, error in
                var parseError: NSError?
                var responseObject: AnyObject? = nil
                
                if(error == nil)
                {
                    if let httpResponse = response as? NSHTTPURLResponse
                    {
                        if(httpResponse.statusCode == 200)
                        {
                            do {
                                if(data == nil)
                                {
                                    doOnMainQueue({ () -> () in
                                        failure(error: "Cound not connect to server")
                                        return
                                    })
                                }
                                else
                                {
                                    responseObject = try NSJSONSerialization.JSONObjectWithData(data!, options: [])
                                    let qualityOfServiceClass = QOS_CLASS_BACKGROUND
                                    let backgroundQueue = dispatch_get_global_queue(qualityOfServiceClass, 0)
                                    dispatch_async(backgroundQueue,
                                        {
                                            success(result: responseObject!)
                                    })
                                }
                            } catch let error as NSError {
                                parseError = error
                                debugPrint(parseError)
                                responseObject = nil
                                doOnMainQueue({ () -> () in
                                    success(result: "")
                                })
                            } catch {
                                fatalError()
                            }
                        }
                        else if(httpResponse.statusCode == 403)
                        {
                            doOnMainQueue({ () -> () in
                                failure(error: "No permissions for the resource.")
                            })
                            
                        }
                        else if (httpResponse.statusCode == 204)
                        {
                            doOnMainQueue({ () -> () in
                                failure(error: "No more data found")
                            })
                        
                        }
                        else if(httpResponse.statusCode == 409)
                        {
                            doOnMainQueue({ () -> () in
                                failure(error: "Conflict in the request")
                            })
                            
                        }
                        else if(httpResponse.statusCode == 500)
                        {
                            doOnMainQueue({ () -> () in
                                failure(error: "Server Internal Error")
                            })
                        }
                        else
                        {
                            doOnMainQueue({ () -> () in
                                failure(error: "Something wrong")
                            })
                        }
                    }
                }
                else
                {
                    doOnMainQueue({ () -> () in
                        failure(error: "Cound not connect to server")
                        return
                    })
                }
                
            })
            task.resume()
        }
        else
        {
            doOnMainQueue({ () -> () in
                failure(error: kInternetNotConnected)
                return
            })
            
        }
    }
    
    
    //MARK:- uploadImage
    
    func postMultiPartDataRequest(image:UIImage , Name fieldName:String, URL url:NSURL, param: NSMutableDictionary, Callback callback: ((Bool , AnyObject?) -> Void))
    {
        dispatch_async(dispatch_get_main_queue(), {
            let request = self.postImageUploadRequest(image, uploadUrl: url, param: param)
            let task = NSURLSession.sharedSession().dataTaskWithRequest(request) { data, response, error in
                if data == nil {
                    callback(false , nil)
                    return
                }
                do {
                    if let jsonResult = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers) as? NSDictionary {
                        let errorStr:String? = jsonResult["error"] as? String
                        dispatch_async(dispatch_get_main_queue()) {
                            if(errorStr != nil)
                            {
                                print("error in post:\(errorStr)" )
                                if(errorStr != nil){
                                    callback(false , errorStr)
                                }
                                else{
                                    callback(false , jsonResult)
                                }
                            }
                            else
                            {
                                callback(true , jsonResult)
                            }
                        }
                    }
                } catch {
                    callback(false , nil)
                }
            }
            task.resume()
        })
    }
    
    
    func postSpecialOfferData(image:UIImage , salonId:Int ,param: NSMutableDictionary, Callback callback: ((Bool , AnyObject?) -> Void)){
        postMultiPartDataRequest(image, Name: "fileToUpload", URL: NSURL(string: Domain + "index.php")!, param: param, Callback: callback)
    }
    
    func postImageUploadRequest(imageView: UIImage, uploadUrl: NSURL, param: NSMutableDictionary) -> NSURLRequest{
        let request = NSMutableURLRequest(URL:uploadUrl);
        request.HTTPMethod = "POST"
        let boundary = generateBoundaryString()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        let imageData = UIImageJPEGRepresentation(imageView, 0.7)
        request.HTTPBody = createBodyWithParameters(param, filePathKey: "fileToUpload", imageDataKey: imageData!, boundary: boundary)
        return request
    }
    
    func createBodyWithParameters(parameters: NSMutableDictionary, filePathKey: String?, imageDataKey: NSData, boundary: String) -> NSData {
        let body = NSMutableData();
        
        if (parameters.count > 0) {
            for i in 0 ..< parameters.count
            {
                body.appendString("--\(boundary)\r\n")
                body.appendString("Content-Disposition: form-data; name=\"\(parameters.allKeys[i])\"\r\n\r\n")
                body.appendString("\(parameters.allValues[i])\r\n")
            }
        }
        let filename = "temp.jpg"
        let mimetype = "image/jpeg"
        body.appendString("--\(boundary)\r\n")
        body.appendString("Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n")
        body.appendString("Content-Type: \(mimetype)\r\n\r\n")
        body.appendData(imageDataKey)
        body.appendString("\r\n")
        body.appendString("--\(boundary)--\r\n")
        return body
    }
    
    
}

extension NSMutableData {
    func appendString(string: String) {
        let data = string.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
        appendData(data!)
    }
}