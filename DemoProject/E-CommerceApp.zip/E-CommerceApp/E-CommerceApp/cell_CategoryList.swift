//
//  cell_CategoryList.swift
//  E-CommerceApp
//
//  Created by LaNet on 9/24/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit

class cell_CategoryList: UITableViewCell {

    @IBOutlet var Product_Img: UIImageView!
    
    @IBOutlet var mfg_Name: UILabel!
    
    @IBOutlet var Product_Price: UILabel!
    @IBOutlet var Product_Name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
