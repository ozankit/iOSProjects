//
//  AppConstants.swift
//  E-CommerceApp
//
//  Created by LaNet on 9/24/16.
//  Copyright © 2016 LaNet. All rights reserved.
//
import UIKit
import Foundation
func doOnMainQueue(closure:()->()) {
    dispatch_async(dispatch_get_main_queue(), closure)
}
struct ScreenSize
{
    static let SCREEN_WIDTH = UIScreen.mainScreen().bounds.size.width
    static let SCREEN_HEIGHT = UIScreen.mainScreen().bounds.size.height
    static let SCREEN_MAX_LENGTH = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    static let SCREEN_MIN_LENGTH = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
}


func appDelegate() -> AppDelegate {
    return (UIApplication.sharedApplication().delegate as! AppDelegate)
}
let WEBURL = ""
let Domain = "http://54.208.19.36/"

let kInternetNotConnected = "Please check your internet connection"

let kInternetGone = "InternetGone"
let kInternetAvailable = "InternetAvailable"
let kInternetAlert = "Lost Network Connection, Try Again Later"
let kLocationAlert = "Not Able to track your Location, Please Enable Location from settings"
let kappDelegate: AppDelegate = (UIApplication.sharedApplication().delegate as! AppDelegate)
