//
//  CategoryListVC.swift
//  E-CommerceApp
//
//  Created by LaNet on 9/24/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit

class CategoryListVC: UIViewController,UITableViewDelegate,UITableViewDataSource,AlertDelegate {
    
    var arrData = NSMutableArray()
    var Alert = CustomeDelegate()
    var ofset = 0
    var loading = UIActivityIndicatorView()
    @IBOutlet var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        Alert.delegate = self
        Alert.view.frame = self.view.frame
        tblView.registerNib(UINib(nibName: "cell_CategoryList",bundle: nil), forCellReuseIdentifier: "cell_CategoryList")
      self.fetchData2("0")
        
        loading.frame = CGRectMake((ScreenSize.SCREEN_WIDTH/2) - 10 , 5, 20, 20)
       loading.color = UIColor.darkGrayColor()
        tblView.dataSource = nil
        tblView.delegate = nil
        
        // Do any additional setup after loading the view.
    }
    
    
    
    func fetchData2(offset : String)
    {
        ServerAPI.sharedInstance.invokeHTTPRequesPOST(NSURL(string: "http://faceted-catalog-api.sophio.com/api/v1/56c49581-11b8-11e4-b695-002590948e4c/catalog-7/category/appearance-accessories/parts")!, isEmbededToken: false, bodyContent: ["year": "","make":"","model":"","category":"","subcategory":"","parttype":"","manufacturer":"","engine":"","submodel":"","searchfor":"","offset":"500","pricerange":"0"], success: { (result) in
            
            dispatch_async(dispatch_get_main_queue(), {
                if(result.isKindOfClass(NSMutableDictionary))
                {
                    var dictResponse = NSMutableDictionary()
                    dictResponse = result as! NSMutableDictionary
                    
                    if dictResponse.objectForKey("results") != nil {
                        let a = dictResponse.valueForKey("results") as! NSMutableDictionary
                            if (a.valueForKey("parts")?.count != 0)
                            {
                            for (var i = 0; i < a.valueForKey("parts")?.count; i += 1)
                             {
                                        let p_Data = ProductData()
                                        let data = a.valueForKey("parts")![i]! as! NSMutableDictionary
                                        p_Data.part_label = data.valueForKey("part_label") as! String
                                        p_Data.mfg_name = data.valueForKey("mfg_name") as! String
                                        p_Data.image_url = data.valueForKey("image_url") as! NSMutableArray
                                        p_Data.pricing = data.valueForKey("pricing")  as! NSMutableDictionary
                                        self.arrData.addObject(p_Data)
                                    }
                                    
                                     self.tblView.reloadData()
                                     self.loading.stopAnimating()
                                    self.tblView.dataSource = self
                                    self.tblView.delegate = self
                          }
                        else
                            {
                           self.Alert.displayAlert("No more Data found")
                        }
                    }
                    else
                    {
                      //  self.loading.stopAnimating()
                        print("no device is register")
                    }
                }
            })
            
            
            })
        { (error) in
            
            self.Alert.displayAlert( error as! String)
        }
    }
    
    
//    func fetchData()
//    {
//        if Reachability.isConnectedToNetwork() == true
//        {
//        let url_string = NSString(format: "http://faceted-catalog-api.sophio.com/api/v1/56c49581-11b8-11e4-b695-002590948e4c/catalog-7/category/appearance-accessories/parts?returntype=json&year=&make=&model=&category=&subcategory=&parttype=&manufacturer=&engine=&submodel=&searchfor=&offset=0&pricerange=0")
//            
//            
//            
//        let url2 = url_string.stringByReplacingOccurrencesOfString(" ", withString: "%20")
//        let url3 = url2.stringByReplacingOccurrencesOfString("\t", withString: "%20")
//        let url4 = url3.stringByReplacingOccurrencesOfString("\n", withString: "%20")
//        let url = NSURL(string: url4 as String)
//        
//        let request = NSMutableURLRequest(URL: url!)
//        request.HTTPMethod = "POST"
//        let data = NSData(contentsOfURL: url!)
//        
//        do
//        {
//            let jsonResult = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions()) as! NSMutableDictionary
//            
//            
//            let a = jsonResult.valueForKey("results") as! NSMutableDictionary
//            for var i = 0; i < a.valueForKey("parts")?.count; i += 1
//            {
//                var p_Data = ProductData()
//                var data = a.valueForKey("parts")![i]! as! NSMutableDictionary
//                p_Data.part_label = data.valueForKey("part_label") as! String
//                p_Data.mfg_name = data.valueForKey("mfg_name") as! String
//                p_Data.image_url = data.valueForKey("image_url") as! NSMutableArray
//                p_Data.pricing = data.valueForKey("pricing")  as! NSMutableDictionary
//                arrData.addObject(p_Data)
//            }
//            var cdd = arrData[10] as! ProductData
//            print(cdd.image_url[0])
//            
//        }
//        catch
//        {}
// 
////        for var i = 0; i<arrData.count; i++ {
////            var cdd = arrData[i] as! ProductData
////             print(cdd.mfg_name)
////        }
//  //  print((arrData as! ProductData).part_label)
//    
//        }
//        else
//        {
//            Alert.displayAlert()
//        
//        
//        }
//    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 200
    }
    
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
               return arrData.count
    }
    
    
    
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
      var headerVW = UIView()
        headerVW.frame = CGRectMake(0, 0, ScreenSize.SCREEN_WIDTH, 40)
        headerVW.backgroundColor = UIColor.clearColor()
        headerVW.addSubview(loading)
        return headerVW
    }
    
     func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        let lastSectionIndex = tableView.numberOfSections - 1
       
                let lastRowIndex = tableView.numberOfRowsInSection(lastSectionIndex) - 1
                if (indexPath.section == lastSectionIndex) && (indexPath.row == lastRowIndex) {
                    loading.startAnimating()
                    ofset += 500
                    fetchData2(String(ofset))
                    //tblView.reloadData()
                  
                }
    }
    

    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell_CategoryList", forIndexPath: indexPath) as! cell_CategoryList
      //  let imgData = arrData[indexPath.row] as! ProductData
      //  var im = imgData as! NSMutableArray
        let cdd = arrData[indexPath.row] as! ProductData
       
        
        let url = NSURL(string: "http://placehold.it/350x150")
         
        
         let thumbImageUrl  =   NSURL(string: String(cdd.image_url[0]))
//        var imgData = NSData(contentsOfURL: NSURL(string: String(cdd.image_url[0]))!)
//        cell.Product_Img.image = UIImage(data: imgData!)

    //  Utils.startActivityIndicatorOnView(self.view, centerPoint: CGPointMake((ScreenSize.SCREEN_WIDTH/2), (ScreenSize.SCREEN_HEIGHT/2)), style: UIActivityIndicatorViewStyle.WhiteLarge, color: UIColor.whiteColor())
       SDWebImageManager.sharedManager().downloadImageWithURL(thumbImageUrl, options:[.RetryFailed] ,progress: nil, completed: {[weak self] (image, error, cached, finished, url) in
            
            if let wSelf = self {
                
                //On Main Thread
                dispatch_async(dispatch_get_main_queue()){
                    if image != nil
                    {
                        cell.Product_Img.image = image
                    }
                    else
                    {
                        cell.Product_Img.image = UIImage(named: "imageNotFound.jpg")
                    }
                   
                }
            }
            })
        cell.Product_Name.text = ((arrData[indexPath.row] as! ProductData).part_label) as! String
        cell.mfg_Name.text = "Mfg.:" + String((arrData[indexPath.row] as! ProductData).mfg_name)
        cell.Product_Price.text = "Price.:" + String((arrData[indexPath.row] as! ProductData).pricing.valueForKey("listprice")!)
        print((arrData[indexPath.row] as! ProductData).part_label)
                return cell
        
    }
    
    


    
}
