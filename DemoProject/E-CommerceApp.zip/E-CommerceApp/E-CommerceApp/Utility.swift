//
//  Utility.swift
//  E-CommerceApp
//
//  Created by LaNet on 9/27/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import Foundation
//
//  Utils.swift
//  SnapTouchApp
//
//  Created by LaNet on 5/24/16.
//  Copyright © 2016 LaNet. All rights reserved.
//


import Foundation
import UIKit
import AssetsLibrary
import Photos
import PhotosUI


class Utils
{
    static func getColorByRGB(R:CGFloat,G:CGFloat,B:CGFloat) -> UIColor
    {
        return UIColor(red: R/255.0, green: G/255.0, blue: B/255.0, alpha: 1.0)
    }
    
    static func verifyEmail(email:String)->Bool
    {
        let ns:NSString = "[A-Za-z0-9\\.]+@[A-Za-z0-9]+\\.[A-Za-z.]{2,6}"
        let pr:NSPredicate = NSPredicate(format: "SELF MATCHES %@",ns)
        return pr.evaluateWithObject(email)
    }
    
    static func verifyText(text:String)->Bool
    {
        if(text != "" && !text.isEmpty)
        {
            return true;
        }
        return false
    }
    
    static func verifyText1(text:String)->Bool
    {
        let ns:NSString = "[A-Za-z ]+"
        let pr:NSPredicate = NSPredicate(format: "SELF MATCHES %@",ns)
        return pr.evaluateWithObject(text)
    }
    
    static func verifyNumber(txtNumber:String,length:Int)->Bool
    {
        let ns:NSString = "[0-9]{\(length)}"
        let pr:NSPredicate = NSPredicate(format: "SELF MATCHES %@",ns)
        return pr.evaluateWithObject(txtNumber)
    }
    
    
    static func saveNSDefaultObject(keyName:String,arr:NSMutableArray) {
        let data = NSKeyedArchiver.archivedDataWithRootObject(arr)
        NSUserDefaults.standardUserDefaults().setObject(data, forKey: keyName)
        NSUserDefaults.standardUserDefaults().synchronize();
    }
    
    static func getArray(keyName:String) -> NSMutableArray? {
        let arr: NSMutableArray = NSMutableArray()
        if let data = NSUserDefaults.standardUserDefaults().objectForKey(keyName) as? NSData {
            return NSKeyedUnarchiver.unarchiveObjectWithData(data) as? NSMutableArray
        }
        return arr
    }
    
    static func getFullDate(dateString:String)-> String
    {
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"//this your string date format
        dateFormatter.timeZone = NSTimeZone(name: "UTC")
        let date = dateFormatter.dateFromString(dateString)
        
        // dateFormatter.dateFormat = "yyyy - MMM  (EEEE - HH:mm a)"///this is you want to convert format
        dateFormatter.dateFormat = "EEEE, MMM dd "///this is you want to convert format
        
        return dateFormatter.stringFromDate(date!)
    }
    
    
    static func startActivityIndicatorOnView(myview : UIView,centerPoint:CGPoint,style:UIActivityIndicatorViewStyle,color:UIColor?)
    {
        let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle:style)
        activityIndicator.center = centerPoint
        if (color != nil)
        {
            activityIndicator.color = color
        }
        myview.addSubview(activityIndicator)
        activityIndicator.layer.zPosition = 1
        activityIndicator.startAnimating()
    }
    static func stopActivityIndicatorOnView(myview : UIView)
    {
        for tmpViews in myview.subviews
        {
            if (tmpViews.isKindOfClass(UIActivityIndicatorView))
            {
                let activityIndicator = tmpViews as! UIActivityIndicatorView
                activityIndicator.stopAnimating()
                activityIndicator.removeFromSuperview()
            }
        }
    }
    
    
    func convertTextToQRCode(text: String, withSize size: CGSize) -> UIImage {
        
        let data = text.dataUsingEncoding(NSISOLatin1StringEncoding, allowLossyConversion: false)
        
        let filter = CIFilter(name: "CIQRCodeGenerator")!
        
        filter.setValue(data, forKey: "inputMessage")
        filter.setValue("L", forKey: "inputCorrectionLevel")
        
        var qrcodeCIImage = filter.outputImage!
        
        let cgImage = CIContext(options:nil).createCGImage(qrcodeCIImage, fromRect: qrcodeCIImage.extent)
        UIGraphicsBeginImageContext(CGSizeMake(size.width * UIScreen.mainScreen().scale, size.height * UIScreen.mainScreen().scale))
        let context = UIGraphicsGetCurrentContext()
        CGContextSetInterpolationQuality(context, .None)
        CGContextDrawImage(context, CGContextGetClipBoundingBox(context), cgImage)
        let preImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        let qrCodeImage = UIImage(CGImage: preImage.CGImage!, scale: 1.0/UIScreen.mainScreen().scale, orientation: .DownMirrored)
        
        return qrCodeImage
    }
    
    
    
    
    
    
    
}



extension UIView {
    class func loadFromNibNamed(nibNamed: String, bundle : NSBundle? = nil) -> UIView? {
        return UINib(
            nibName: nibNamed,
            bundle: bundle
            ).instantiateWithOwner(nil, options: nil)[0] as? UIView
    }
}




extension UITextField
{
    func isEmpty()->Bool
    {
        let trimmedString = self.text?.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        if trimmedString!.characters.count == 0
        {
            return true
        }
        else
        {
            return false
        }
    }
}