//
//  ProductData.swift
//  E-CommerceApp
//
//  Created by LaNet on 9/24/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import Foundation


class ProductData
{
    var part_label = ""
    var mfg_name = ""
    var pricing = NSMutableDictionary()
    var image_url = NSMutableArray()

}