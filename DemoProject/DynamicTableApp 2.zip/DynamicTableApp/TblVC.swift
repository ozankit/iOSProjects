//
//  TblVC.swift
//  DynamicTableApp
//
//  Created by LaNet on 8/9/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit

class TblVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
     var arrData = NSMutableArray()
     var arrBool = NSMutableArray()
     @IBOutlet var btnSelectClick: UIButton!
     @IBOutlet var btnCancelClick: UIButton!
     var disflag = false
     @IBOutlet var tblV: UITableView!
     override func viewDidLoad() {
        super.viewDidLoad()
            setArrValues()
            tblV.registerNib(UINib(nibName: "Tbl_Cell",bundle: nil), forCellReuseIdentifier: "Tbl_Cell")

        // Do any additional setup after loading the view.
    }
    
    func setArrValues()
    {
        arrData = ["The ...........................................................................................................................................","The1 table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly.","The table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly. If you have a bug in your implementation, the UI will show the moved cell as moved by the user, but the data object will have a different order.","The table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly. If you have a bug in your implementation, the UI will show the moved cell as moved by the user, but the data object will have a different order. To check for the correctness of your implementation, use NSLog or reload the table after the move operation.","The ...........................................................................................................................................","The1 table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly.","The table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly. If you have a bug in your implementation, the UI will show the moved cell as moved by the user, but the data object will have a different order.","The table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly. If you have a bug in your implementation, the UI will show the moved cell as moved by the user, but the data object will have a different order. To check for the correctness of your implementation, use NSLog or reload the table after the move operation.","The ...........................................................................................................................................","The1 table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly.","The table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly. If you have a bug in your implementation, the UI will show the moved cell as moved by the user, but the data object will have a different order.","The table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly. If you have a bug in your implementation, the UI will show the moved cell as moved by the user, but the data object will have a different order. To check for the correctness of your implementation, use NSLog or reload the table after the move operation.","The ...........................................................................................................................................","The1 table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly.","The table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly. If you have a bug in your implementation, the UI will show the moved cell as moved by the user, but the data object will have a different order.","The table view is not reloaded after the move operation - UITableView trusts you to change the underlying model list accordingly. If you have a bug in your implementation, the UI will show the moved cell as moved by the user, but the data object will have a different order. To check for the correctness of your implementation, use NSLog or reload the table after the move operation."]
            arrBool.removeAllObjects()
            for var i in 0..<arrData.count
            {
                arrBool.addObject(false)
        
            }

    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
        
    }
    @IBAction func btnSelectClick(sender: AnyObject) {
        disflag = true
        tblV.reloadData()
     //    tblV.editing = true
    }
    
    
    @IBAction func btnCancelClick(sender: AnyObject) {
       // tblV.editing = false
        setArrValues()
        disflag = false
        tblV.reloadData()
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        
        return heightForView((arrData[indexPath.row] as? String)!, font: UIFont.systemFontOfSize(15), width: tableView.frame.size.width) + 30
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier("Tbl_Cell", forIndexPath: indexPath) as! Tbl_Cell
        
       //  cell.imageView?.frame = cell.imgCkeck.frame
          //cell.imageView?.image = UIImage(named: "tick-2.png")
        if disflag == true
        {
            if arrBool[indexPath.row] as! NSObject == true
            {
                cell.imgCkeck.image = UIImage(named: "Checked-Checkbox")
            }
            else
            {
                 cell.imgCkeck.image = UIImage(named: "Unchecked-Checkbox")
                
            }
           
        }
        else
        {
           cell.imgCkeck.image = UIImage(named: "")
//            cell.lbText.frame = CGRectMake(0, 0, cell.frame.size.width, CGFloat.max)
//            cell.lbText.numberOfLines = 0
//            cell.lbText.lineBreakMode = NSLineBreakMode.ByWordWrapping
//            cell.lbText.text = arrData[indexPath.row] as? String
//            cell.lbText.sizeToFit()
        }
        
            cell.lbText.frame = CGRectMake(0, 0, cell.imgCkeck.frame.origin.x, CGFloat.max)
            cell.lbText.numberOfLines = 0
            cell.lbText.lineBreakMode = NSLineBreakMode.ByWordWrapping
            cell.lbText.text = arrData[indexPath.row] as? String
            cell.lbText.sizeToFit()
            cell.imgCkeck.tag = indexPath.row
          
        
        
        return cell
    }
    func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle {
        return UITableViewCellEditingStyle(rawValue: 3)!
    }

    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        let isCheck = arrBool[indexPath.row] as! Bool
        
        if disflag == true
        {
            arrBool.replaceObjectAtIndex(indexPath.row, withObject: !isCheck)
        }
        
        tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.None)

    }
    
    
    
    func heightForView(text:String,font:UIFont,width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRectMake(0, 0, width, CGFloat.max))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.ByWordWrapping
        label.font = font
        label.text = text
        
        label.sizeToFit()
        return label.frame.height
    }
    
    
    
//    let font = UIFont(name: "Helvetica", size: 20.0)
//    
//    var height = heightForView("This is just a load of text", font: font, width: 100.0)

    
//    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
