//
//  Tbl_Cell.swift
//  DynamicTableApp
//
//  Created by LaNet on 8/9/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit

class Tbl_Cell: UITableViewCell {

    @IBOutlet var lbText: UILabel!
    
    @IBOutlet var cv: UIView!
    @IBOutlet var btnClick: UIButton!
    @IBOutlet var imgCkeck: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
