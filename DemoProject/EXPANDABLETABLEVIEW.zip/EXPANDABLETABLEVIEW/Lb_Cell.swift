//
//  Lb_Cell.swift
//  EXPANDABLETABLEVIEW
//
//  Created by LaNet on 8/4/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit

class Lb_Cell: UITableViewCell {

    @IBOutlet weak var DisView: UIView!
    @IBOutlet weak var LbDis: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
       
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
