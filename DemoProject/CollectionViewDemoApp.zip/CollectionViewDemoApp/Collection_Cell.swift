//
//  Collection_Cell.swift
//  CollectionViewDemoApp
//
//  Created by LaNet on 8/9/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit

class Collection_Cell: UICollectionViewCell {

    @IBOutlet var img: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
