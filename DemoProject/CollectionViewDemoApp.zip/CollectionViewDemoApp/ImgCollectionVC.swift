//
//  ImgCollectionVC.swift
//  CollectionViewDemoApp
//
//  Created by LaNet on 8/9/16.
//  Copyright © 2016 LaNet. All rights reserved.
//

import UIKit

class ImgCollectionVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {

    @IBOutlet var loader: UIActivityIndicatorView!
    @IBOutlet var collectionView: UICollectionView!
    var arrImg = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
        
       collectionView.registerNib(UINib(nibName:"Collection_Cell",bundle: nil) , forCellWithReuseIdentifier: "Collection_Cell")
        
        arrImg = ["http://52.27.52.241:8080/maistylz-webservice/images/women_all.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_top.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_dress.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_dress.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_bag.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_outwear.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_shoes.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_acess.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_formal.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_sports.jpg", "http://52.27.52.241:8080/maistylz-webservice/images/women_lingerie.jpg","http://52.27.52.241:8080/maistylz-webservice/images/women_swimwear.jpg"]
        

        // Do any additional setup after loading the view.
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrImg.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell  = collectionView.dequeueReusableCellWithReuseIdentifier("Collection_Cell", forIndexPath: indexPath) as! Collection_Cell
        cell.backgroundColor = UIColor.blueColor()
        let url = NSURL(string: arrImg[indexPath.row] as! String)
        
      
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)) { 
            
            let imageData = NSData(contentsOfURL: url!)
            let bgImage = UIImage(data:imageData!)
            cell.img.image = bgImage
        }
        
        
        
           // cell.img.image = UIImage(named: arrImg[indexPath.row] as! String)
        return cell
    }
    
//    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize
//    {
//        return CGSize(width: collectionView.frame.size.width/2.2, height: 200)
//    }
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        
        // flow layout have all the important info like spacing, inset of collection view cell, fetch it to find out the attributes specified in xib file
        guard let flowLayout = collectionViewLayout as? UICollectionViewFlowLayout else {
            return CGSize()
        }
        
        // subtract section left/ right insets mentioned in xib view
        
        let widthAvailbleForAllItems =  (collectionView.frame.width - flowLayout.sectionInset.left - flowLayout.sectionInset.right)
        
        // Suppose we have to create nColunmns
        // widthForOneItem achieved by sunbtracting item spacing if any
        
        let widthForOneItem = widthAvailbleForAllItems / 2 - flowLayout.minimumInteritemSpacing
        
        
        // here height is mentioned in xib file or storyboard
        return CGSize(width: CGFloat(widthForOneItem), height: (flowLayout.itemSize.height))
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
